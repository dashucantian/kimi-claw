/**pages/practice/practice.js**/
const app = getApp()

// 音效映射
const SOUND_MAP = {
  largeGong: '/assets/large_gong.mp3',      // 大磬 - 开场
  smallBell: '/assets/small_bell.mp3',      // 引磬 - 结束
  woodenFish: '/assets/wooden_fish.mp3',    // 木鱼 - 准备收功
  windChime: '/assets/wind_chime.mp3',      // 风铃 - 观心
  waterDrop: '/assets/water_drop.mp3'       // 水滴 - 止息
}

Page({
  data: {
    statusBarHeight: 44,
    duration: 3,
    mode: 'guided',
    remainingTime: 180,
    isPlaying: false,
    isPaused: false,
    audioEnabled: true,
    stageLabel: '准备开始',
    guideText: '点击开始，进入止观练习',
    formattedTime: '03:00',
    currentPhase: 'prepare'  // prepare, stop, observe, finish
  },

  timer: null,
  startTime: null,
  playedCues: new Set(),
  waterDropTimer: null,
  windChimeTimer: null,

  onLoad(options) {
    const systemInfo = wx.getSystemInfoSync()
    const duration = parseInt(options.duration) || 3
    const mode = options.mode || 'guided'
    
    this.setData({
      statusBarHeight: systemInfo.statusBarHeight,
      duration,
      mode,
      remainingTime: duration * 60,
      formattedTime: this.formatTime(duration * 60),
      audioEnabled: app.globalData.settings.audioEnabled
    })
  },

  onUnload() {
    this.clearAllTimers()
  },

  // 格式化时间
  formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  },

  // 播放音效
  playSound(soundName, volume = 0.6) {
    if (!this.data.audioEnabled) return
    
    const src = SOUND_MAP[soundName]
    if (!src) return
    
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.src = src
    innerAudioContext.volume = volume
    innerAudioContext.play()
    
    innerAudioContext.onEnded(() => innerAudioContext.destroy())
    innerAudioContext.onError(() => innerAudioContext.destroy())
  },

  // 开始练习
  startTimer() {
    this.setData({ isPlaying: true, isPaused: false })
    this.startTime = new Date()
    this.playedCues.clear()
    
    const totalSeconds = this.data.duration * 60
    
    // 播放开场大磬（低音量，顺滑）
    if (this.data.audioEnabled) {
      this.playSound('largeGong', 0.5)
      wx.vibrateLong()
    }
    
    // 主计时器
    this.timer = setInterval(() => {
      const remaining = this.data.remainingTime - 1
      this.setData({
        remainingTime: remaining,
        formattedTime: this.formatTime(remaining)
      })
      
      // 检查各阶段
      this.checkPhases(totalSeconds, remaining)
      
      // 结束
      if (remaining <= 0) {
        this.completePractice()
      }
    }, 1000)
  },

  // 检查各阶段
  checkPhases(total, remaining) {
    const elapsed = total - remaining
    
    // 0-15秒：开场调身调息调心（大磬已播放）
    if (elapsed >= 0 && elapsed < 15) {
      if (!this.playedCues.has('prepare')) {
        this.playedCues.add('prepare')
        this.setData({
          stageLabel: '调身调息',
          guideText: '调整坐姿，自然呼吸，让心安定',
          currentPhase: 'prepare'
        })
      }
    }
    
    // 16秒：进入止息，开始水滴声
    if (elapsed >= 16 && !this.playedCues.has('stop_start')) {
      this.playedCues.add('stop_start')
      this.setData({
        stageLabel: '止息',
        guideText: '保持觉知，安住于止',
        currentPhase: 'stop'
      })
      this.startWaterDrop()
    }
    
    // 1分30秒（90秒）：转入观心，风铃声
    if (elapsed >= 90 && !this.playedCues.has('observe_start')) {
      this.playedCues.add('observe_start')
      this.stopWaterDrop()
      this.setData({
        stageLabel: '观心',
        guideText: '觉察心念，不随不拒',
        currentPhase: 'observe'
      })
      this.playSound('windChime', 0.5)
      this.startWindChime()
    }
    
    // 最后15秒：木鱼准备收功
    if (remaining <= 15 && remaining > 5 && !this.playedCues.has('prepare_end')) {
      this.playedCues.add('prepare_end')
      this.stopWindChime()
      this.setData({
        stageLabel: '准备收功',
        guideText: '慢慢把觉知带回',
        currentPhase: 'finish'
      })
      this.playSound('woodenFish', 0.6)
      wx.vibrateShort({ type: 'medium' })
    }
  },

  // 水滴声循环（每3-5秒一次）
  startWaterDrop() {
    // 立即播放一次
    this.playSound('waterDrop', 0.4)
    
    // 循环播放
    const playLoop = () => {
      if (this.data.currentPhase !== 'stop') return
      
      this.playSound('waterDrop', 0.4)
      
      // 随机间隔3-5秒
      const interval = 3000 + Math.random() * 2000
      this.waterDropTimer = setTimeout(playLoop, interval)
    }
    
    this.waterDropTimer = setTimeout(playLoop, 4000)
  },

  stopWaterDrop() {
    if (this.waterDropTimer) {
      clearTimeout(this.waterDropTimer)
      this.waterDropTimer = null
    }
  },

  // 风铃声循环（3秒一次，间隔10-8秒递减）
  startWindChime() {
    let interval = 10000  // 初始10秒
    
    const playLoop = () => {
      if (this.data.currentPhase !== 'observe') return
      
      this.playSound('windChime', 0.5)
      
      // 间隔递减（10秒 -> 8秒）
      interval = Math.max(8000, interval - 500)
      this.windChimeTimer = setTimeout(playLoop, interval)
    }
    
    // 3秒后第一次播放
    this.windChimeTimer = setTimeout(playLoop, 3000)
  },

  stopWindChime() {
    if (this.windChimeTimer) {
      clearTimeout(this.windChimeTimer)
      this.windChimeTimer = null
    }
  },

  // 暂停
  pauseTimer() {
    this.clearAllTimers()
    this.setData({ isPlaying: false, isPaused: true })
  },

  // 继续
  resumeTimer() {
    this.startTimer()
  },

  // 结束练习
  endPractice() {
    this.clearAllTimers()
    
    wx.showModal({
      title: '结束练习',
      content: '确定要结束当前练习吗？',
      confirmText: '结束',
      cancelText: '继续',
      success: (res) => {
        if (res.confirm) {
          this.saveAndExit()
        } else {
          this.resumeTimer()
        }
      }
    })
  },

  // 完成练习
  completePractice() {
    this.clearAllTimers()
    
    // 播放引磬结束（3-5秒）
    if (this.data.audioEnabled) {
      this.playSound('smallBell', 0.6)
      wx.vibrateLong()
    }
    
    this.saveAndExit(true)
  },

  // 保存并跳转到评分页
  saveAndExit(completed = false) {
    const actualDuration = this.startTime 
      ? Math.floor((new Date() - this.startTime) / 1000 / 60)
      : 0
    
    const record = {
      id: Date.now(),
      date: new Date().toISOString(),
      duration: this.data.duration,
      mode: this.data.mode,
      completed,
      actualDuration: actualDuration < 1 ? 1 : actualDuration
    }
    
    const records = wx.getStorageSync('zhiguan_records') || []
    records.unshift(record)
    wx.setStorageSync('zhiguan_records', records)
    
    // 跳转到评分页
    wx.redirectTo({
      url: `/pages/feedback/feedback?recordId=${record.id}&duration=${this.data.duration}&completed=${completed}`
    })
  },

  // 清除所有定时器
  clearAllTimers() {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
    this.stopWaterDrop()
    this.stopWindChime()
  },

  // 切换音频
  toggleAudio() {
    const audioEnabled = !this.data.audioEnabled
    this.setData({ audioEnabled })
    app.globalData.settings.audioEnabled = audioEnabled
    wx.setStorageSync('zhiguan_settings', app.globalData.settings)
  },

  // 返回
  goBack() {
    if (this.data.isPlaying) {
      this.pauseTimer()
      wx.showModal({
        title: '退出练习',
        content: '练习正在进行中，确定要退出吗？',
        success: (res) => {
          if (res.confirm) {
            this.clearAllTimers()
            wx.navigateBack()
          } else {
            this.resumeTimer()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  }
})