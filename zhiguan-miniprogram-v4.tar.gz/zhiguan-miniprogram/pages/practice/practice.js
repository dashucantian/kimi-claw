/**pages/practice/practice.js**/
const app = getApp()

// 阶段配置
const STAGES = [
  { name: '准备', label: '准备开始', guide: '点击开始，进入止观练习', sound: 'largeGong' },
  { name: '调身', label: '调身', guide: '让身体自然放松，脊柱轻轻挺直', sound: 'waterDrop' },
  { name: '调息', label: '调息', guide: '吸气...呼气...保持自然的呼吸节奏', sound: 'smallBell' },
  { name: '观心', label: '观心', guide: '觉察身体的感觉，不评判，只是知道', sound: 'windChime' },
  { name: '收功', label: '收功', guide: '慢慢把觉知带回，准备结束练习', sound: 'largeGong' }
]

// 音效映射
const SOUND_MAP = {
  largeGong: '/assets/large_gong.mp3',
  smallBell: '/assets/small_bell.mp3',
  windChime: '/assets/wind_chime.mp3',
  waterDrop: '/assets/water_drop.mp3'
}

// 20分钟版音频时间点
const AUDIO_CUES_20MIN = [
  { time: 0, sound: 'largeGong', label: '开场' },
  { time: 30, sound: 'waterDrop', label: '调身开始' },
  { time: 120, sound: 'smallBell', label: '入止' },
  { time: 600, sound: 'windChime', label: '止中过渡' },
  { time: 900, sound: 'windChime', label: '观心过渡' },
  { time: 1080, sound: 'smallBell', label: '回向' },
  { time: 1170, sound: 'smallBell', label: '准备收功' },
  { time: 1200, sound: 'largeGong', label: '结束' }
]

Page({
  data: {
    statusBarHeight: 44,
    duration: 3,
    mode: 'guided',
    remainingTime: 180,
    isPlaying: false,
    isPaused: false,
    audioEnabled: true,
    currentStage: 0,
    stageLabel: '准备开始',
    guideText: '点击开始，进入止观练习',
    formattedTime: '03:00'
  },

  timer: null,
  startTime: null,
  playedCues: new Set(),
  audioContext: null,

  onLoad(options) {
    const systemInfo = wx.getSystemInfoSync()
    const duration = parseInt(options.duration) || 3
    const mode = options.mode || 'guided'
    
    this.setData({
      statusBarHeight: systemInfo.statusBarHeight,
      duration,
      mode,
      remainingTime: duration * 60,
      formattedTime: this.formatTime(duration * 60),
      audioEnabled: app.globalData.settings.audioEnabled
    })
  },

  onUnload() {
    this.clearTimer()
    this.stopAllSounds()
  },

  // 格式化时间
  formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  },

  // 更新阶段
  updateStage() {
    const { duration, remainingTime, mode } = this.data
    const elapsed = duration * 60 - remainingTime
    const progress = elapsed / (duration * 60)
    
    let stageIndex = 0
    if (progress > 0) {
      if (progress < 0.17) stageIndex = 1
      else if (progress < 0.67) stageIndex = 2
      else if (progress < 0.89) stageIndex = 3
      else stageIndex = 4
    }
    
    const stage = STAGES[stageIndex]
    this.setData({
      currentStage: stageIndex,
      stageLabel: stage.label,
      guideText: mode === 'guided' ? stage.guide : ''
    })
    
    // 播放阶段音效
    if (this.data.audioEnabled && stageIndex > 0) {
      this.playStageSound(stageIndex)
    }
  },

  // 播放阶段音效
  playStageSound(stageIndex) {
    // 使用微信震动
    const patterns = ['', 'light', 'medium', 'heavy', 'heavy']
    wx.vibrateShort({ type: patterns[stageIndex] || 'medium' })
    
    // 播放对应音效
    const stage = STAGES[stageIndex]
    if (stage && stage.sound) {
      this.playSound(stage.sound)
    }
  },

  // 播放指定音效
  playSound(soundName) {
    const src = SOUND_MAP[soundName]
    if (!src) return
    
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.src = src
    innerAudioContext.volume = 0.7
    innerAudioContext.play()
    
    innerAudioContext.onEnded(() => {
      innerAudioContext.destroy()
    })
    
    innerAudioContext.onError((err) => {
      console.error('音频播放失败:', err)
      innerAudioContext.destroy()
    })
  },

  // 停止所有音效
  stopAllSounds() {
    // 微信小程序会自动管理，这里主要是清理引用
    this.audioContext = null
  },

  // 开始计时
  startTimer() {
    this.setData({ isPlaying: true, isPaused: false })
    this.startTime = new Date()
    this.playedCues.clear()
    
    // 播放开始音效（大磬）
    if (this.data.audioEnabled) {
      this.playSound('largeGong')
      wx.vibrateLong()
    }
    
    this.updateStage()
    
    this.timer = setInterval(() => {
      this.setData({
        remainingTime: this.data.remainingTime - 1
      }, () => {
        this.setData({
          formattedTime: this.formatTime(this.data.remainingTime)
        })
        
        // 检查阶段变化
        const newStage = this.getCurrentStage()
        if (newStage !== this.data.currentStage) {
          this.updateStage()
        }
        
        // 检查20分钟版时间点
        if (this.data.duration === 20) {
          this.checkAudioCues()
        }
        
        // 结束
        if (this.data.remainingTime <= 0) {
          this.completePractice()
        }
      })
    }, 1000)
  },

  // 获取当前阶段
  getCurrentStage() {
    const { duration, remainingTime } = this.data
    const elapsed = duration * 60 - remainingTime
    const progress = elapsed / (duration * 60)
    
    if (progress <= 0) return 0
    if (progress < 0.17) return 1
    if (progress < 0.67) return 2
    if (progress < 0.89) return 3
    return 4
  },

  // 检查音频时间点（20分钟版）
  checkAudioCues() {
    const { duration, remainingTime } = this.data
    const elapsed = duration * 60 - remainingTime
    
    AUDIO_CUES_20MIN.forEach(cue => {
      if (elapsed >= cue.time && !this.playedCues.has(cue.time)) {
        this.playedCues.add(cue.time)
        this.playSound(cue.sound)
        wx.vibrateShort({ type: 'light' })
        console.log(`播放音效: ${cue.label} (${cue.time}s)`)
      }
    })
  },

  // 暂停
  pauseTimer() {
    this.clearTimer()
    this.setData({ isPlaying: false, isPaused: true })
  },

  // 继续
  resumeTimer() {
    this.startTimer()
  },

  // 结束练习
  endPractice() {
    this.clearTimer()
    
    wx.showModal({
      title: '结束练习',
      content: '确定要结束当前练习吗？',
      confirmText: '结束',
      cancelText: '继续',
      success: (res) => {
        if (res.confirm) {
          this.saveAndExit()
        } else {
          if (this.data.isPaused) {
            this.setData({ isPaused: false })
          }
        }
      }
    })
  },

  // 完成练习
  completePractice() {
    this.clearTimer()
    
    // 播放结束音效（大磬）
    if (this.data.audioEnabled) {
      this.playSound('largeGong')
      wx.vibrateLong()
    }
    
    this.saveAndExit(true)
  },

  // 保存并退出
  saveAndExit(completed = false) {
    const actualDuration = this.startTime 
      ? Math.floor((new Date() - this.startTime) / 1000 / 60)
      : 0
    
    // 保存记录
    const record = {
      id: Date.now(),
      date: new Date().toISOString(),
      duration: this.data.duration,
      mode: this.data.mode,
      completed,
      actualDuration: actualDuration < 1 ? 1 : actualDuration
    }
    
    const records = wx.getStorageSync('zhiguan_records') || []
    records.unshift(record)
    wx.setStorageSync('zhiguan_records', records)
    
    // 跳转到完成页或返回
    if (completed) {
      wx.showToast({
        title: '练习完成',
        icon: 'success'
      })
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    } else {
      wx.navigateBack()
    }
  },

  // 清除定时器
  clearTimer() {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
  },

  // 切换音频
  toggleAudio() {
    const audioEnabled = !this.data.audioEnabled
    this.setData({ audioEnabled })
    app.globalData.settings.audioEnabled = audioEnabled
    wx.setStorageSync('zhiguan_settings', app.globalData.settings)
  },

  // 返回
  goBack() {
    if (this.data.isPlaying) {
      this.pauseTimer()
      wx.showModal({
        title: '退出练习',
        content: '练习正在进行中，确定要退出吗？',
        success: (res) => {
          if (res.confirm) {
            this.clearTimer()
            wx.navigateBack()
          } else {
            this.resumeTimer()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  }
})