/**pages/practice/practice.js**/
const app = getApp()

// 阶段配置 - 5种音效对应5个阶段
const STAGES = [
  { 
    name: '准备', 
    label: '准备开始', 
    guide: '点击开始，进入止观练习',
    sound: 'largeGong',      // 大磬 - 开场
    soundLabel: '大磬开场'
  },
  { 
    name: '调身', 
    label: '调身', 
    guide: '让身体自然放松，脊柱轻轻挺直',
    sound: 'waterDrop',      // 水滴 - 调身
    soundLabel: '水滴调身'
  },
  { 
    name: '调息', 
    label: '调息', 
    guide: '吸气...呼气...保持自然的呼吸节奏',
    sound: 'smallBell',      // 引磬 - 入止
    soundLabel: '引磬入止'
  },
  { 
    name: '观心', 
    label: '观心', 
    guide: '觉察身体的感觉，不评判，只是知道',
    sound: 'windChime',      // 风铃 - 过渡
    soundLabel: '风铃过渡'
  },
  { 
    name: '收功', 
    label: '收功', 
    guide: '慢慢把觉知带回，准备结束练习',
    sound: 'woodenFish',     // 木鱼 - 回向/收功
    soundLabel: '木鱼回向'
  }
]

// 音效映射
const SOUND_MAP = {
  largeGong: '/assets/large_gong.mp3',      // 大磬 - 低沉浑厚，开场/结束
  smallBell: '/assets/small_bell.mp3',      // 引磬 - 清脆高亢，入止/收功
  woodenFish: '/assets/wooden_fish.mp3',    // 木鱼 - 短促有力，回向/计数
  windChime: '/assets/wind_chime.mp3',      // 风铃 - 悠扬绵长，过渡
  waterDrop: '/assets/water_drop.mp3'       // 水滴 - 轻柔清澈，调身
}

// 20分钟完整版音频时间点配置
// 根据5种音效设计8个关键时间点
const AUDIO_CUES_20MIN = [
  { time: 0,      sound: 'largeGong',   label: '大磬开场',    desc: '练习开始' },
  { time: 30,     sound: 'waterDrop',   label: '水滴调身',    desc: '调整身体姿势' },
  { time: 120,    sound: 'smallBell',   label: '引磬入止',    desc: '进入止息状态' },
  { time: 600,    sound: 'windChime',   label: '风铃过渡',    desc: '止中过渡提醒' },
  { time: 900,    sound: 'windChime',   label: '风铃过渡',    desc: '转入观心' },
  { time: 1080,   sound: 'woodenFish',  label: '木鱼回向',    desc: '开始回向' },
  { time: 1170,   sound: 'smallBell',   label: '引磬收功',    desc: '准备收功' },
  { time: 1200,   sound: 'largeGong',   label: '大磬结束',    desc: '练习结束' }
]

Page({
  data: {
    statusBarHeight: 44,
    duration: 3,
    mode: 'guided',
    remainingTime: 180,
    isPlaying: false,
    isPaused: false,
    audioEnabled: true,
    currentStage: 0,
    stageLabel: '准备开始',
    guideText: '点击开始，进入止观练习',
    formattedTime: '03:00',
    lastSoundLabel: ''  // 显示最后播放的音效
  },

  timer: null,
  startTime: null,
  playedCues: new Set(),

  onLoad(options) {
    const systemInfo = wx.getSystemInfoSync()
    const duration = parseInt(options.duration) || 3
    const mode = options.mode || 'guided'
    
    this.setData({
      statusBarHeight: systemInfo.statusBarHeight,
      duration,
      mode,
      remainingTime: duration * 60,
      formattedTime: this.formatTime(duration * 60),
      audioEnabled: app.globalData.settings.audioEnabled
    })
  },

  onUnload() {
    this.clearTimer()
    this.stopAllSounds()
  },

  // 格式化时间
  formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  },

  // 更新阶段
  updateStage() {
    const { duration, remainingTime, mode } = this.data
    const elapsed = duration * 60 - remainingTime
    const progress = elapsed / (duration * 60)
    
    let stageIndex = 0
    if (progress > 0) {
      if (progress < 0.17) stageIndex = 1      // 0-17% 调身
      else if (progress < 0.67) stageIndex = 2  // 17-67% 调息
      else if (progress < 0.89) stageIndex = 3  // 67-89% 观心
      else stageIndex = 4                       // 89-100% 收功
    }
    
    const stage = STAGES[stageIndex]
    this.setData({
      currentStage: stageIndex,
      stageLabel: stage.label,
      guideText: mode === 'guided' ? stage.guide : '',
      lastSoundLabel: stage.soundLabel
    })
    
    // 播放阶段音效
    if (this.data.audioEnabled && stageIndex >= 0) {
      this.playStageSound(stageIndex)
    }
  },

  // 播放阶段音效
  playStageSound(stageIndex) {
    const stage = STAGES[stageIndex]
    if (!stage || !stage.sound) return
    
    // 播放对应音效
    this.playSound(stage.sound)
    
    // 震动反馈（不同强度）
    const patterns = ['heavy', 'light', 'medium', 'light', 'medium']
    wx.vibrateShort({ type: patterns[stageIndex] || 'medium' })
  },

  // 播放指定音效
  playSound(soundName) {
    const src = SOUND_MAP[soundName]
    if (!src) return
    
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.src = src
    
    // 根据音效类型调整音量
    const volumeMap = {
      largeGong: 0.8,    // 大磬声音大些
      smallBell: 0.6,    // 引磬适中
      woodenFish: 0.7,   // 木鱼适中
      windChime: 0.5,    // 风铃轻柔
      waterDrop: 0.4     // 水滴轻柔
    }
    innerAudioContext.volume = volumeMap[soundName] || 0.6
    
    innerAudioContext.play()
    
    innerAudioContext.onEnded(() => {
      innerAudioContext.destroy()
    })
    
    innerAudioContext.onError((err) => {
      console.error('音频播放失败:', err)
      innerAudioContext.destroy()
    })
  },

  // 停止所有音效
  stopAllSounds() {
    // 微信小程序会自动管理
  },

  // 开始计时
  startTimer() {
    this.setData({ isPlaying: true, isPaused: false })
    this.startTime = new Date()
    this.playedCues.clear()
    
    // 播放开始音效（大磬）
    if (this.data.audioEnabled) {
      this.playSound('largeGong')
      wx.vibrateLong()
    }
    
    // 短版本（3/5/10分钟）立即进入调身阶段
    if (this.data.duration < 20) {
      setTimeout(() => {
        this.updateStage()
      }, 2000)  // 2秒后进入调身
    }
    
    this.timer = setInterval(() => {
      this.setData({
        remainingTime: this.data.remainingTime - 1
      }, () => {
        this.setData({
          formattedTime: this.formatTime(this.data.remainingTime)
        })
        
        // 检查阶段变化
        const newStage = this.getCurrentStage()
        if (newStage !== this.data.currentStage) {
          this.updateStage()
        }
        
        // 检查20分钟版时间点
        if (this.data.duration === 20) {
          this.checkAudioCues()
        }
        
        // 结束
        if (this.data.remainingTime <= 0) {
          this.completePractice()
        }
      })
    }, 1000)
  },

  // 获取当前阶段
  getCurrentStage() {
    const { duration, remainingTime } = this.data
    const elapsed = duration * 60 - remainingTime
    const progress = elapsed / (duration * 60)
    
    if (progress <= 0) return 0
    if (progress < 0.17) return 1
    if (progress < 0.67) return 2
    if (progress < 0.89) return 3
    return 4
  },

  // 检查音频时间点（20分钟版）
  checkAudioCues() {
    const { duration, remainingTime } = this.data
    const elapsed = duration * 60 - remainingTime
    
    AUDIO_CUES_20MIN.forEach(cue => {
      if (elapsed >= cue.time && !this.playedCues.has(cue.time)) {
        this.playedCues.add(cue.time)
        this.playSound(cue.sound)
        
        // 更新显示
        this.setData({
          lastSoundLabel: cue.label,
          stageLabel: cue.desc
        })
        
        wx.vibrateShort({ type: 'light' })
        console.log(`[${cue.time}s] ${cue.label}: ${cue.desc}`)
      }
    })
  },

  // 暂停
  pauseTimer() {
    this.clearTimer()
    this.setData({ isPlaying: false, isPaused: true })
  },

  // 继续
  resumeTimer() {
    this.startTimer()
  },

  // 结束练习
  endPractice() {
    this.clearTimer()
    
    wx.showModal({
      title: '结束练习',
      content: '确定要结束当前练习吗？',
      confirmText: '结束',
      cancelText: '继续',
      success: (res) => {
        if (res.confirm) {
          this.saveAndExit()
        } else {
          if (this.data.isPaused) {
            this.setData({ isPaused: false })
          }
        }
      }
    })
  },

  // 完成练习
  completePractice() {
    this.clearTimer()
    
    // 播放结束音效（大磬）
    if (this.data.audioEnabled) {
      this.playSound('largeGong')
      wx.vibrateLong()
    }
    
    this.saveAndExit(true)
  },

  // 保存并退出
  saveAndExit(completed = false) {
    const actualDuration = this.startTime 
      ? Math.floor((new Date() - this.startTime) / 1000 / 60)
      : 0
    
    // 保存记录
    const record = {
      id: Date.now(),
      date: new Date().toISOString(),
      duration: this.data.duration,
      mode: this.data.mode,
      completed,
      actualDuration: actualDuration < 1 ? 1 : actualDuration
    }
    
    const records = wx.getStorageSync('zhiguan_records') || []
    records.unshift(record)
    wx.setStorageSync('zhiguan_records', records)
    
    // 跳转到完成页或返回
    if (completed) {
      wx.showToast({
        title: '练习完成',
        icon: 'success'
      })
      setTimeout(() => {
        wx.navigateBack()
      }, 2000)  // 延长到2秒，让大磬声播完
    } else {
      wx.navigateBack()
    }
  },

  // 清除定时器
  clearTimer() {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
  },

  // 切换音频
  toggleAudio() {
    const audioEnabled = !this.data.audioEnabled
    this.setData({ audioEnabled })
    app.globalData.settings.audioEnabled = audioEnabled
    wx.setStorageSync('zhiguan_settings', app.globalData.settings)
  },

  // 返回
  goBack() {
    if (this.data.isPlaying) {
      this.pauseTimer()
      wx.showModal({
        title: '退出练习',
        content: '练习正在进行中，确定要退出吗？',
        success: (res) => {
          if (res.confirm) {
            this.clearTimer()
            wx.navigateBack()
          } else {
            this.resumeTimer()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  }
})